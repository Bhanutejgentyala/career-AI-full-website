from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    MONGODB_URL: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "placement_portal"

    JWT_SECRET: str = "change-me"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""

    UPLOAD_DIR: str = "uploads"

    class Config:
        env_file = ".env"


settings = Settings()
function showPage(pageId, button = null) {

    // Hide all pages
    const pages = document.querySelectorAll(".page");

    pages.forEach(page => {
        page.classList.remove("active-page");
    });

    // Show selected page
    const selectedPage = document.getElementById(pageId);

    if (selectedPage) {
        selectedPage.classList.add("active-page");
    }

    // Update navigation
    const navItems = document.querySelectorAll(".nav-item");

    navItems.forEach(item => {
        item.classList.remove("active");
    });

    if (button) {
        button.classList.add("active");
    }

    // Update page title
    const titles = {
        dashboard: "Dashboard",
        profile: "My Profile",
        resume: "Resume Analysis",
        skills: "Skill Gap Analysis",
        aptitude: "Aptitude Test",
        interview: "Interview Preparation",
        career: "AI Career Recommendation",
        companies: "Company Matching"
    };

    document.getElementById("pageTitle").innerText =
        titles[pageId] || "Dashboard";

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// Resume Analysis

function analyzeResume() {

    const file = document.getElementById("resumeFile").files[0];

    if (!file) {
        alert("Please upload your resume first.");
        return;
    }

    const result = document.getElementById("resumeResult");

    result.classList.remove("hidden");

    result.scrollIntoView({
        behavior: "smooth"
    });
}


// Aptitude answer

function answer(button) {

    const buttons =
        document.querySelectorAll(".answers button");

    buttons.forEach(btn => {
        btn.style.background = "white";
        btn.style.borderColor = "#e2e5ec";
    });

    button.style.background = "#eeeaff";
    button.style.borderColor = "#635bff";

    if (button.innerText === "60 km/h") {
        setTimeout(() => {
            alert("Correct! Speed = Distance / Time = 120 / 2 = 60 km/h");
        }, 200);
    } else {
        setTimeout(() => {
            alert("Incorrect. Try again!");
        }, 200);
    }
}


// Logout

function logout() {

    const confirmLogout =
        confirm("Are you sure you want to logout?");

    if (confirmLogout) {
        alert("Logged out successfully.");
    }
}
#!/usr/bin/env python3
"""CareerAI local demo server. Uses only Python standard-library modules."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import sqlite3, json, mimetypes
ROOT = Path(__file__).resolve().parent
DB = ROOT / "careerai.db"
def connect():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row; return con
def init_db():
    with connect() as c:
        c.execute("CREATE TABLE IF NOT EXISTS profile (id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS saved (name TEXT PRIMARY KEY)")
        c.execute("CREATE TABLE IF NOT EXISTS quiz (id INTEGER PRIMARY KEY AUTOINCREMENT, score INTEGER, total INTEGER, percentage INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        c.execute("INSERT OR IGNORE INTO profile(id,data) VALUES(1,'{}')")
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,fmt,*args): print("[CareerAI]",fmt%args)
    def send_json(self,data,status=200):
        body=json.dumps(data).encode(); self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(body))); self.send_header("Access-Control-Allow-Origin","*"); self.end_headers(); self.wfile.write(body)
    def read_json(self):
        n=int(self.headers.get("Content-Length",0))
        if n>1_000_000: raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        if self.path.startswith("/api/dashboard"):
            with connect() as c:
                p=json.loads(c.execute("SELECT data FROM profile WHERE id=1").fetchone()["data"])
                saved=[r["name"] for r in c.execute("SELECT name FROM saved")]
                q=c.execute("SELECT score,total,percentage FROM quiz ORDER BY id DESC LIMIT 1").fetchone()
            return self.send_json({"profile":p,"saved":saved,"quiz":dict(q) if q else None})
        if self.path.startswith("/api/"): return self.send_json({"detail":"API route not found"},404)
        return super().do_GET()
    def do_POST(self):
        try: data=self.read_json()
        except Exception as e: return self.send_json({"detail":str(e)},400)
        if self.path=="/api/profile":
            allowed={"name","email","phone","branch","college","cgpa","year","targetRole","skills","interests"}
            clean={k:str(v)[:2000] for k,v in data.items() if k in allowed}
            if not clean.get("name","").strip(): return self.send_json({"detail":"Full name is required"},400)
            with connect() as c: c.execute("UPDATE profile SET data=? WHERE id=1",(json.dumps(clean),))
            return self.send_json(clean)
        if self.path=="/api/saved":
            name=str(data.get("name","")).strip()[:100]
            if not name:return self.send_json({"detail":"Company name is required"},400)
            with connect() as c:c.execute("INSERT OR IGNORE INTO saved(name) VALUES(?)",(name,))
            return self.send_json({"saved":name},201)
        if self.path=="/api/quiz":
            try: score=int(data["score"]); total=int(data["total"]); percentage=int(data["percentage"])
            except Exception:return self.send_json({"detail":"Invalid quiz result"},400)
            if total<1 or score<0 or score>total:return self.send_json({"detail":"Invalid score"},400)
            with connect() as c:c.execute("INSERT INTO quiz(score,total,percentage) VALUES(?,?,?)",(score,total,percentage))
            return self.send_json({"score":score,"total":total,"percentage":percentage},201)
        if self.path=="/api/reset":
            with connect() as c:
                c.execute("UPDATE profile SET data='{}' WHERE id=1"); c.execute("DELETE FROM saved"); c.execute("DELETE FROM quiz")
            return self.send_json({"message":"Reset complete"})
        return self.send_json({"detail":"API route not found"},404)
    def do_DELETE(self):
        if self.path.startswith("/api/saved/"):
            from urllib.parse import unquote
            name=unquote(self.path.split("/api/saved/",1)[1])
            with connect() as c:c.execute("DELETE FROM saved WHERE name=?",(name,))
            return self.send_json({"deleted":name})
        return self.send_json({"detail":"API route not found"},404)
if __name__=="__main__":
    init_db()
    print("CareerAI running at http://localhost:8000")
    print("Press Ctrl+C to stop.")
    ThreadingHTTPServer(("127.0.0.1",8000),Handler).serve_forever()
